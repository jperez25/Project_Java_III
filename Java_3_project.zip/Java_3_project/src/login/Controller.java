package login;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

//imports...

public class Controller {

 @FXML
 private Button bt1 ;
 @FXML
 private TextField txtfl;

 // called by the FXML loader after the labels declared above are injected:
	 public void initialize() {
	
	     // do initialization and configuration work...
	
	     // trivial example, could also be done directly in the fxml:
		 bt1.setOnAction(e->{
			 txtfl.setText("Just a test");
			 
		 }
		);
		 txtfl.requestFocus();
	}
}